package org.lassilos.color.mixin.client;

import net.minecraft.class_4068;
import net.minecraft.class_437;
import net.minecraft.class_6379;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_437.class)
public interface ScreenAccessor {
    @Invoker("addDrawableChild")
    <T extends net.minecraft.class_364 & class_4068 & class_6379> T callAddDrawableChild(T child);
}

