package org.lassilos.color.client;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class ColorConfigScreen extends class_437 {
    private final class_437 parent;
    private boolean showSingle;
    private boolean showMulti;
    private boolean notifyScreenOpen;

    public ColorConfigScreen(class_437 parent) {
        super(class_2561.method_43470("Color Mod Settings"));
        this.parent = parent;
        this.showSingle = ColorConfig.shouldShowInSingleplayer();
        this.showMulti = ColorConfig.shouldShowInMultiplayer();
        this.notifyScreenOpen = ColorConfig.isScreenOpenNotificationEnabled();
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        int centerX = this.field_22789 / 2;
        int centerY = this.field_22790 / 2;

        ColorButton singleBtn = new ColorButton(centerX - 100, centerY - 50, 200, 20,
                class_2561.method_43470("Show in Singleplayer: " + showSingle), (button) -> {
            showSingle = !showSingle;
            ColorConfig.setShowInSingleplayer(showSingle);
            button.method_25355(class_2561.method_43470("Show in Singleplayer: " + showSingle));
        });

        ColorButton multiBtn = new ColorButton(centerX - 100, centerY - 20, 200, 20,
                class_2561.method_43470("Show in Multiplayer: " + showMulti), (button) -> {
            showMulti = !showMulti;
            ColorConfig.setShowInMultiplayer(showMulti);
            button.method_25355(class_2561.method_43470("Show in Multiplayer: " + showMulti));
        });

        ColorButton notifyBtn = new ColorButton(centerX - 100, centerY + 10, 200, 20,
                class_2561.method_43470("Notify when screen opened: " + notifyScreenOpen), (button) -> {
            notifyScreenOpen = !notifyScreenOpen;
            ColorConfig.setScreenOpenNotificationEnabled(notifyScreenOpen);
            button.method_25355(class_2561.method_43470("Notify when screen opened: " + notifyScreenOpen));
        });

        ColorButton done = new ColorButton(centerX - 100, centerY + 40, 200, 20,
                class_2561.method_43470("Done"), (button) -> {
            // return to parent screen
            if (this.field_22787 != null) this.field_22787.method_1507(parent);
        });

        this.method_37063(singleBtn);
        this.method_37063(multiBtn);
        this.method_37063(notifyBtn);
        this.method_37063(done);
    }

    @Override
    public void method_25394(class_332 drawContext, int mouseX, int mouseY, float tickDelta) {
        // Let the superclass render background, children and tooltips first
        super.method_25394(drawContext, mouseX, mouseY, tickDelta);

        // Draw the screen title on top so we don't trigger background blur twice
        class_2561 title = this.field_22785;
        int textWidth = this.field_22793.method_27525(title);
        int x = (this.field_22789 - textWidth) / 2;
        drawContext.method_27535(this.field_22793, title, x, this.field_22790 / 2 - 90, 0xFFFFFF);
    }
}
