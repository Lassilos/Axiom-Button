package org.lassilos.color.client;

import net.minecraft.class_2561;
import net.minecraft.class_4185;

public class ColorButton extends class_4185 {
    public ColorButton(int x, int y, int width, int height, class_2561 message, class_4241 onPress) {
        super(x, y, width, height, message, onPress, field_40754);
    }
}
